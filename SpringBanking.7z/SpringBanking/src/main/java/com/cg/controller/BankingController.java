package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Account;
import com.cg.exception.BankingException;
import com.cg.service.IBankService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class BankingController {

	@Autowired
	IBankService service;

	@RequestMapping(path = "/login/{mobile}/{password}", method = RequestMethod.GET, produces = {
			"application/json" })
	@ResponseBody
	public String verifyLogInData(@PathVariable String mobile, @PathVariable String password)
			throws BankingException {
		Integer accountId=0;
		try {
			Account account = service.verifyLogIn(mobile, password);
			accountId = account.getAccountId();
		} catch (NullPointerException e) {
			throw new BankingException("Wrong username/password");
		}
		return accountId.toString();
	}

	@RequestMapping(path = "/create", method = RequestMethod.POST, produces = { "application/json" })
	public int addAccount(@RequestBody Account account) throws BankingException {

		int accountId=0;
		Account addAccount;
		try {

			addAccount = service.addAccount(account);
			//System.out.println(account.getName());
			accountId = addAccount.getAccountId();

		}

		catch (Exception e) {
			throw new BankingException("Account already exist");
		}

		return accountId;

	}

}
