package com.cg.exception;

public class BankingException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4461200082712333528L;

	public BankingException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
