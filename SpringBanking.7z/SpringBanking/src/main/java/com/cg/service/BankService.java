package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Account;
import com.cg.dao.ICreateAccountRepository;


@Service
public class BankService implements IBankService {

	
	
	@Autowired
	ICreateAccountRepository repositoryCreateAccount;
	
	@Override
	public Account verifyLogIn(String mobile, String password) {
		return repositoryCreateAccount.verifyLogin(mobile, password);
	}

	@Override
	public Account addAccount(Account account) {
		// TODO Auto-generated method stub
		return repositoryCreateAccount.save(account);
	}

}
