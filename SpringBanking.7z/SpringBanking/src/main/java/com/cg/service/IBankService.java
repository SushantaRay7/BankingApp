package com.cg.service;

import com.cg.beans.Account;


public interface IBankService {

	public Account verifyLogIn(String mobile,String password);


	public Account addAccount(Account account);
}
