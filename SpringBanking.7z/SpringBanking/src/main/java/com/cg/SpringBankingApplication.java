package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBankingApplication.class, args);
	}

}
